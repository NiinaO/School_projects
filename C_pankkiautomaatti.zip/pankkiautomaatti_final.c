/* pankkiautomaatti_final.c
 *
 *
 *  Ohjelma simuloi pankkiautomaatin toimintaa: kortin lukua, PIN-koodin tarkistusta,
 *  rahan nostamista, saldon tarkistusta ja rahan tallettamista. Ohjelma kysyy k�ytt�j�lt�
 *  pankkikortin numeroa ja tarkistaa numeron perusteella pin-koodin ja saldon erillisest�
 *  .tili-muotoisesta tiedostosta.
 *
 *  Tiedostossa pin-koodi on ensimm�isell� rivill� ja tilin saldo toisella rivill�. Tilinumero
 *  on tiedoston nimi.
 *
 *  Ohjelma vaatii oikean pin-koodin ennen saldon tarkistusta tai nostotapahtuman alkua.
 *  Ohjelma antaa yritt�� sy�tt�� pin-koodia kolme kertaa ennen kuin se keskeytt�� tapahtuman.
 *
 *  Rahaa k�sitelt�ess� minimisumma on 20 euroa ja maksimisumma on 1000 euroa tai nostoissa
 *  tilin saldon verran. Nostetun tai talletetun summan tulee olla k�sitelt�viss� 20 ja 50 euron
 *  setelein� ja nostot toteutetaan aina mahdollisimman suurina setelein�. Nostettava summa
 *  v�hennet��n tililt� ja talletettu summa lis�t��n tilille.
 *
 *  Ohjelma py�rii, kunnes k�ytt�j� ilmoittaa lopettavansa ohjelman k�yt�n.
 *
 *
 *
 *  Niina Oikarinen 2018
 *
 */


#include <stdio.h>
#include <string.h>
#include <math.h>


#define KOKO 50


int lueInt(void);
int pinKoodinLukeminen(char []);
int pinKoodinTarkistus(char[], int);
void lueRoskat();
void setelienLkm(int);
void valikkoToiminto(void);
void rahanSiirtaminen(char[], int);
void valikkoJatketaanko(void);
void lueMerkkijono(char [], int);
void saldonMuokkaus(double, char[]);
double lueSaldo(char tilinumero[]);



/* main - p��ohjelma
 *
 * Suorittaa pankkiautomaatti-simulaation, kutsuu tarvittavat alifunktiot.
 *
 * Parametrit: void
 *
 * Paluuarvo (int): 0, jos ohjelma on suoritettu onnistuneesti
 *
 */
int main (void){
   char tilinumero[KOKO];
   int jatka = 1;
   int toiminto;
   int tarkistettuKoodi = 0;

   while (1 == jatka){

         printf("\nTervetuloa! \nAloita syottamalla tilinumero:\n");
         lueMerkkijono(tilinumero, KOKO);
         strcat(tilinumero, ".tili");

         tarkistettuKoodi = pinKoodinLukeminen(tilinumero);

         while (1 == tarkistettuKoodi){

            valikkoToiminto();
            toiminto = lueInt();

            switch (toiminto){

               case 1:{
                  rahanSiirtaminen(tilinumero, 1);
                  break;
               }
               case 2:{
                  rahanSiirtaminen(tilinumero, 2);
                  break;
               }
               case 3:{
                  printf("\nTilin saldo on %.2lf euroa\n", lueSaldo(tilinumero));
                  break;
               }
               case 0:{
                  printf("\nTilin tarkastelu keskeytetaan\n");
                  tarkistettuKoodi = 0;
                  break;
               }
               default:{
                  printf("\nValitse toiminto \n");
               }
            }
         }

         do{
            valikkoJatketaanko();
            jatka = lueInt();
            if (0 == jatka){
               printf("\nOhjelma suljetaan, kiitos asioinnista!\n\n");
            }
         }while (jatka != 1 && jatka != 0);
   }

   return 0;
}




/* valikkoToiminto - tulostaa k�ytt�j�lle valikon eri toiminnoista
 *
 * Tulostaa ruudulle valikon, jonka perusteella k�ytt�j� valitsee toimintansa.
 *
 * Parametrit: void
 *
 * Paluuarvo: void
 *
 */
void valikkoToiminto(void){
   printf("\nValitse toiminto:\n");
   printf("  1  Kateisnosto\n");
   printf("  2  Talletus tilille\n");
   printf("  3  Saldon tarkistus\n");
   printf("  0  Keskeyta\n");
}



/* valikkoJatketaanko - tulostaa k�ytt�j�lle kysymyksen jatketaanko ohjelman k�ytt��
 *
 * Tulostaa valikon, jonka perusteella k�ytt�j� valitsee jatkaako seuraavaan asiointiin
 * vai lopettaako ohjelman k�yt�n.
 *
 * Parametrit: void
 *
 * Paluuarvo: void
 *
 */
void valikkoJatketaanko(void){
   printf("\nJatketaanko seuraavaan asiointiin?\n");
   printf("Paina:\n");
   printf("  1  Jatka\n");
   printf("  0  Lopeta\n");
}



/* lueMerkkijono - lukee k�ytt�j�n sy�tt�m�n merkkijonon
 *
 * Varmistaa, ett� sy�tetty tieto on char[]-muodossa.
 * Tallentaa n�pp�imist�lt� sy�tetyn tiedon funktiota kutsuttaessa m��ritetylle char[]-muuttujalle.
 * Funktiosta ei p��se pois ennen kuin tieto on sy�tetty oikeassa muodossa.
 *
 * Parametrit:
 *    mjono(char []): merkkijono, johon k�ytt�j�n sy�tt�m� vastaus tallennetaan
 *    koko (int): merkkijonon maksimipituus
 *
 * Paluuarvo: void
 *
 */
void lueMerkkijono(char mjono[], int koko){

   fgets(mjono, koko, stdin);

   if( mjono[strlen(mjono) - 1] == '\n'){
      mjono[strlen(mjono) - 1] = '\0';
   }else{
      lueRoskat();
   }
}



/* lueInt - lukee k�ytt�j�n sy�tt�m�n kokonaisluvun
 *
 * Varmistaa, ett� sy�tetty tieto on int-muodossa.
 * Palauttaa oikeassa muodossa n�pp�imist�lt� sy�tetyn tiedon yl�funktiolle.
 * Funktiosta ei p��se pois ennen kuin tieto on sy�tetty oikeassa muodossa.
 *
 * Parametrit: void
 *
 * Paluuarvo (int): kokonaisluku, jonka k�ytt�j� sy�tt��
 *
 */
int lueInt(void){
   int luku;
   char mki;
   int result;

   while((result = scanf("%d%c", &luku, &mki))== 0 || result==2 && mki!='\n'){
      lueRoskat();
      printf("Syote vaarassa muodossa, syota tieto uudelleen:\n");
   }
   return luku;
}



/* lueRoskat - tyhjent�� puskurin
 *
 * Parametrit: void
 *
 * Paluuarvo: void
 *
 */
void lueRoskat(void){
   char poista;
   while((poista = getchar()) != '\n'){
      ;
   }
}



/* pinKoodinLukeminen - avaa tiedoston ja vertaa k�ytt�j�n sy�tt�m�� pin-koodia tiedostosta l�ytyv��n pin-koodiin
 *
 * Avaa tiedoston ja lukee sielt� pin-koodin.
 * Kutsuu aliohjelman pin-koodin tarkistamista varten.
 * Vastaanottaa aliohjelmalta tiedon, vastaako pin-koodi k�ytt�j�n sy�tt�m�� arvoa.
 * Palauttaa yl�funktiolle tiedon, onko tiedoston lukeminen ja pin-koodin tarkistus onnistunut.
 *
 * Parametrit:
 *    tiedostonNimi (char[]): avattavan tiedoston nimi
 *
 * Paluuarvo (int): arvo 1, jos k�ytt�j�n sy�tt�m� pin-koodi vastaa tiedostosta luettua pin-koodia
 *                  arvo 0, jos k�ytt�j�n sy�tt�m� pin-koodi ei vastaa tiedostosta luettua pin-koodia
 *
 */
int pinKoodinLukeminen(char tiedostonNimi[]){
   FILE *tiedosto;
   char pinOikea[5];
   int tarkistettuKoodi;

   tiedosto = fopen(tiedostonNimi, "r");

   if(tiedosto == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      fgets(pinOikea,5, tiedosto);
      tarkistettuKoodi = pinKoodinTarkistus(pinOikea, 5);
   }

   fclose(tiedosto);

   return (tarkistettuKoodi);
}



/* pinKoodinTarkistus - tarkistaa onko k�ytt�j�n sy�tt�m� pin-koodi oikein
 *
 * Ohjelma kysyy k�ytt�j�lt� pin-koodia ja vertaa, vastaako sy�tetty pin-koodi yl�ohjelmalta annettua
 * pin-koodia.
 * K�ytt�j�ll� on kolme yrityst� saada pin-koodi oikein ennen kuin funktio palauttaa yl�ohjelmalle tiedon
 * palauttaa ohjelma alkuun.
 *
 * Parametrit:
 *    oikeaPin (char[]): oikea pin-koodi
 *    koko (int): oikean pin-koodin pituus
 *
 * Paluuarvo (int): arvon 1, jos k�ytt�j�n sy�tt�m� pin-koodi vastaa oikeaa pin-koodia
 *                  arvon 0, jos k�ytt�j�n sy�tt�m� pin-koodi ei vastaa oikeaa pin-koodia kolmen yrityksen j�lkeen
 *
 */
int pinKoodinTarkistus(char oikeaPin[], int koko){
   char pinSyotetty[koko+1];
   int i = 0;
   int tarkistettuKoodi = 1;

   do{
      printf("\nSyota 4 numeroinen PIN-koodi:\n");
      lueMerkkijono(pinSyotetty, koko+1);
      i++;

      if (0 != strcmp(pinSyotetty, oikeaPin)){
         printf("\nVaara PIN-koodi\n");
      }
   }while ((0 != strcmp(pinSyotetty, oikeaPin)) && i < 3);

   if (0 != strcmp(pinSyotetty, oikeaPin)){
      printf("\nPIN-koodi vaarin, kaytto keskeytetaan\n\n");
      tarkistettuKoodi = 0;
   }else{
      printf("\nPIN-koodi oikein\n\n");
   }

   return (tarkistettuKoodi);
}



/* rahanSiirtaminen - kysyy siirrett�v�n rahasumman ja tarkistaa voidaanko siirto suorittaa
 *
 * Funktio kysyy k�ytt�j�lt� siirrett�v�� rahasummaa ja tarkistaa tiedostosta, onko tilill�
 * tarpeeksi katetta nostoa varten.
 * Funktio tarkistaa, onko rahasumma siirret�viss� setelein� (euro).
 * Rahasummalta vaadittavat ominaisuudet: 20 - 1000 euroa, summan tulee olla k�sitelt�viss�
 * 20 ja 50 euron setelein�.
 * Jos siirrett�v� summa on 0 euroa, siirtotapahtuma keskeytet��n.
 * Jos rahasumma on hyv�ksytty� muotoa, funktio kutsuu aliohjelmaa, joka laskee nostettavien
 * seteleiden lukum��r�t.
 * Jos siirto on suoritettu hyv�ksytysti, funktio kutsuu aliohjelmaa, joka muokkaa tilin saldoa
 * sy�tetyn summan verran.
 *
 * Parametrit:
 *    tilinumero (char[]): avattavan tiedoston nimi
 *    kasittely (int): k�sittelyn tyyppi
 *                      1 = nosto
 *                      2 = talletus
 *
 * Paluuarvo: void
 *
 */
void rahanSiirtaminen(char tilinumero[], int kasittely){
   double saldo;
   int temp;
   int siirrettavaSumma = -1;
   int siirrettavanSummanJakojaannos = -1;
   int nostoOk = -1;
   int naytaSaldo = 0;

   saldo = lueSaldo(tilinumero);

   do {
      if(1 == kasittely){
         printf("\nValitse nostettava rahasumma:\n");
      }
      if(2 == kasittely){
         printf("\nValitse talletettava rahasumma:\n");
      }
      printf(" 0 keskeyttaa tapahtuman\n");
      siirrettavaSumma = lueInt();
      siirrettavanSummanJakojaannos = siirrettavaSumma;

      if (0 == siirrettavaSumma){
         printf("\nRahan siirtaminen keskeytetty\n");
         break;
      }

      if (saldo >= siirrettavaSumma || 2 == kasittely){
         if (siirrettavaSumma > 1000){
            if(1 == kasittely){
               printf("\nMaksiminosto 1000 euroa\n");
            }
            if(2 == kasittely){
               printf("\nMaksimitalletus 1000 euroa\n");
            }
         }else{
            if (siirrettavaSumma < 20){
               if(1 == kasittely){
                  printf("\nMiniminosto 20 euroa\n");
               }
               if(2 == kasittely){
                  printf("\nMinimitalletus 20 euroa\n");
               }
            }else{
               if ((30 == siirrettavaSumma) || (0 != (siirrettavanSummanJakojaannos %= 10))){
                  printf("Summan taytyy olla kasiteltavissa 20 ja 50 euron seteleilla\n\n");
               }else{
                  nostoOk = 1;
               }
            }
         }
      }else{
         if(1 == kasittely){
            printf("\nNostettava summa ylittaa tilin saldon, nostoa ei voi suorittaa\n\n");
            nostoOk = 1;
         }
         if(2 == kasittely){
            nostoOk = 1;
         }
      }
   } while (1 != nostoOk);

   if (0 == siirrettavaSumma){
      ;
   }else{
      if (1 == kasittely){
         if(saldo >= siirrettavaSumma){
            setelienLkm(siirrettavaSumma);
            saldonMuokkaus(siirrettavaSumma, tilinumero);
         }
      }
      if (2 == kasittely){
         saldonMuokkaus((0-siirrettavaSumma), tilinumero);
         printf("\nTilille talletettu %d euroa\n", siirrettavaSumma);
      }
   }
}



/* lueSaldo - lukee tilin saldon tiedostosta
 *
 * Funktio lukee tiedoston toiselta rivilt� double-tyyppi� olevan arvon ja palauttaa
 * sen yl�funktiolle.
 *
 * Parametrit:
 *    tilinumero (char[]): avattavan tiedoston nimi
 *
 * Paluuarvo (double): tiedostosta luettu saldo
 *
 */
double lueSaldo(char tilinumero[]){
   FILE *tiedosto;
   double saldo;
   int temp;

   tiedosto = fopen(tilinumero, "r");

   if(tiedosto == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      fscanf(tiedosto, "%d", &temp);
      fscanf(tiedosto, "%lf", &saldo);
   }

   fclose(tiedosto);

   return saldo;
}



/* setelienLkm - laskee nostettavien seteleiden lukum��r�t
 *
 * Funktio laskee montako 50 euron seteli� ja montako 20 euron seteli� k�ytt�j�lle annetaan.
 * Setelit annetaan k�ytt�j�lle mahdollisimman suurina.
 * Funktio tulostaa annettavien seteleiden lukum��r�t.
 *
 * Parametrit:
 *    nostettavaSumma (int): summa, jolle seteleiden lukum��r�t lasketaan
 *
 * Paluuarvo: void
 *
 */
void setelienLkm(int nostettavaSumma){
    int tempViisik = nostettavaSumma;
    int kaksik = -1;
    int viisik = -1;
    int temp = 0;

    if (0 == (tempViisik %= 50)){
        viisik = (nostettavaSumma / 50);
        kaksik = 0;
    }else{
        if (10 == (tempViisik %= 50) || 30 == (tempViisik %= 50)){
            viisik = floor(nostettavaSumma / 50) -1;
            temp = nostettavaSumma - viisik * 50;
            kaksik = temp / 20;
        }else{
            viisik = floor(nostettavaSumma / 50);
            temp = nostettavaSumma - viisik * 50;
            kaksik = (temp / 20);
        }
    }
    if(-1 == kaksik || -1 == viisik){
        printf("Jotain meni pieleen\n\n");
        return;
    }else{
        printf("\nNostettava summa on %d euroa, rahaa nostettu %d kpl 50 euron setelia ja %d kpl 20 euron setelia\n\n", nostettavaSumma, viisik, kaksik);
    }
}



/* saldonVahennys - muokkaa tilin saldoa siirrett�v�n summan verran
 *
 * Funktio ylikirjoittaa annetun tiedostonnimen. Ylikirjoituksessa ensimm�isen rivin tiedot
 * (pin-koodi) pysyv�t samana ja toiselle riville kirjoitetaan tilin saldo rahan nostamisen tai
 * talletuksen j�lkeen.
 *
 * Parametrit:
 *    siirrettavaSumma (double): summa, joka tililt� v�hennet��n
 *    tilinumero (char[]): avattavan tiedoston nimi
 *
 * Paluuarvo: void
 *
 */
void saldonMuokkaus(double siirrettavaSumma, char tilinumero[]){
   FILE *tiedosto;
   double saldo;
   char pinKoodi[5];
   char temp [20];


   tiedosto = fopen(tilinumero, "r");

   if(tiedosto == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      fscanf(tiedosto, "%s", pinKoodi);
      fscanf(tiedosto, "%lf", &saldo);
   }


   saldo = (saldo - siirrettavaSumma);
   snprintf(temp, sizeof(temp), "%.2f", saldo);


   tiedosto = fopen(tilinumero, "w");

   if(tiedosto == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      fprintf(tiedosto, "%s\n%s", pinKoodi, temp);
   }

   fclose(tiedosto);

}
