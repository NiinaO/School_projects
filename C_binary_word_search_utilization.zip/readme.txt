Keskener�inen toteutus bin��ripuuta hy�dynt�v�st� ohjelmasta, jossa tarkoituksena on tallettaa yhden kirjan (.txt)
sanat bin��riseen hakupuuhun ja k�yd� l�pi toisen kirjan sanoja, kunnes 50 ensimm�ist� sanaa on l�ytynyt, jotka esiintyv�t 
toisessa kirjassa, mutta eiv�t ensimm�isess� kirjassa (hakupuussa).

Tunnetut ongelmat:
- ei k�sittele oikein muotoa http://www.xxx.xxx olevaa sanaa
- 1/5 testauksessa k�ytetyist� kirjojen yhdistelmist� ei toimi, ohjelma kaatuu kesken bin��risen hakupuun rakentamisen.



2019 Niina Oikarinen