/* lopputyo_TRA_Oikarinen_Niina_final.c
 *
 *    Ohjelma aukaisee kaksi kirjaa (muodossa .txt) ja tallentaa ensimm�isen kirjan sanat
 *    binaaripuuhun, sek� vertaa toisen kirjan sanoja binaaripuuhun tallennettuihin sanoihin.
 *    Tulostaa 50 ensimm�ist� sanaa, joita ei l�ydy ensimm�isest� kirjasta.
 *
 *    Ohjelma tunnistaa sanat, joissa on merkkej� a-z, A-Z sek� ' (heittomerkki). Isot ja pienet
 *    alkukirjaimet eiv�t vaikuta sanan tunnistamiseen.
 *
 *
 *
 *    2019 Niina Oikarinen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_BOOK_NAME_LENGTH 20
#define MAX_WORD_LENGTH 100


// binary tree:

// Defines data to store in tree
typedef char* data_type;

// Defines node and its pointer
typedef struct bstnd {
	struct bstnd* parent;
	struct bstnd* left;
	struct bstnd* right;
	data_type data;
} bstnode, *pbstnode;

// Defines the tree
typedef struct bt {
	pbstnode root;
} bst;

// binary tree functions
pbstnode bst_min(pbstnode rt);
pbstnode bst_max(pbstnode rt);
pbstnode bst_search(bst bt, data_type key);
void bst_insert(bst *bt, data_type key);
int bst_remove(bst *bt,data_type key);
void print_node(pbstnode n);
void print_tree_inorder(bst bt);
void bst_delete(pbstnode node);

// own functions
void readString(char [], int);
void readTrash(void);
void secondBookStoraging(char [], bst*);
void firstBookSearch(char [], bst*);
void changetoLowerCase(char*);
char* checkWord (char*, char*);
char* substring(char*, int, int);



int main (void){

   int choice = 0;
   int repeatQuestion = 1;

   char firstBook[MAX_BOOK_NAME_LENGTH];
   char secondBook[MAX_BOOK_NAME_LENGTH];


   bst treeSecondBook;
	treeSecondBook.root=NULL;


   printf("Tarjolla olevat kirjat:\n  Metamorph\n  TheGun\n  Species\n  WarPeace\n  Ulysses\n\n");

   printf("Syota kirjan 1. nimi:\n");
   readString(firstBook, MAX_BOOK_NAME_LENGTH);
   strcat(firstBook, ".txt");

   printf("\nSyota kirjan 2. nimi:\n");
   readString(secondBook, MAX_BOOK_NAME_LENGTH);
   strcat(secondBook, ".txt");


   secondBookStoraging(secondBook, &treeSecondBook);

   if(treeSecondBook.root != NULL){
      firstBookSearch(firstBook, &treeSecondBook);
   }else{
      printf("Puuta ei voitu muodostaa\n");
   }

   bst_delete(treeSecondBook.root);

   return 0;
}



// Lukee merkkijonon
void readString(char string[], int length){

   fgets(string, length, stdin);

   if( string[strlen(string) - 1] == '\n'){
      string[strlen(string) - 1] = '\0';
   }else{
      readTrash();
   }
}



// tyhjent�� puskurin
void readTrash(void){
   char empty;
   while((empty = getchar()) != '\n'){
      ;
   }
}



/* secondBookStoraging(char[], bst*)
 * Lukee tiedostoa sana kerrallaan ja lis�� luetun sanan binaariseen hakupuuhun.
 *
 */
void secondBookStoraging(char fileName[], bst* treeTable){
   FILE *file;
   char word[MAX_WORD_LENGTH];
   char* subWord;
   char* insWord;
   int i;

   file = fopen(fileName, "r");

   if(file == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      printf("\nAvasi kirjan %s\n", fileName);

      for(i = 0; !feof(file); i++){
         fscanf(file, "%s", word);

         changetoLowerCase(word);
         subWord = checkWord(word, subWord);

         insWord = (char*) malloc((strlen(word)+1)*sizeof(char));
         strcpy(insWord, word);
         insWord[strlen(word)] = 0;

         bst_insert(treeTable, insWord);

         while(subWord != NULL && subWord[0] != '\0'){
            strcpy(word, subWord);
            subWord = checkWord(word, subWord);

            insWord = (char*) malloc((strlen(word)+1)*sizeof(char));
            strcpy(insWord, word);
            insWord[strlen(word)] = 0;

            bst_insert(treeTable, insWord);
         }
      }
   }
   fclose(file);
}



/* firstBookSearch(char[], bst*)
 *
 * Lukee tiedostoa sana kerrallaan ja vertaa sanaa muodostettuun binaariseen hakupuuhun.
 * Tulostaa 50 ensimm�ist� sanaa, jotka l�ytyv�t tiedostosta, mutta eiv�t hakupuusta.
 * Tulostettavat sanat lis�t��n hakupuuhun, jotta ne eiv�t tulostuisi uudestaan.
 *
 */
void firstBookSearch(char fileName[], bst* treeTable){
   FILE *file;
   char word[MAX_WORD_LENGTH];
   char wordList[50];
   char* subWord;
   char* insWord;
   int i, k;
   int j = 0;

   file = fopen(fileName, "r");

   if(file == NULL){
      printf("Virhe avatessa tiedostoa\n");
   }else{
      printf("Avasi kirjan %s\n\n", fileName);

      for(i = 0; j < 50; i++){
         fscanf(file, "%s", word);

         changetoLowerCase(word);
         subWord = checkWord(word, subWord);

         if(!bst_search(*treeTable, word)){
            insWord = (char*) malloc((strlen(word)+1)*sizeof(char));
            strcpy(insWord, word);
            insWord[strlen(word)] = 0;

            bst_insert(treeTable, insWord);

            strcpy(&wordList[j], insWord);
            printf("%d  %s\n",j+1, &wordList[j]);
            j++;
         }
         while(subWord != NULL && subWord[0] != '\0'){
            strcpy(word, subWord);
            subWord = checkWord(word, subWord);

            insWord = (char*) malloc((strlen(word)+1)*sizeof(char));
            strcpy(insWord, word);
            insWord[strlen(word)] = 0;

            if(!bst_search(*treeTable, word)){
               bst_insert(treeTable, insWord);

               strcpy(&wordList[j], insWord);
               printf("%d  %s\n",j+1, &wordList[j]);
               j++;
            }
         }
         if(feof(file)){
            printf("Ei loydy tarpeeksi uniikkeja sanoja\n");
            break;
         }
      }
   }

   fclose(file);
}



// muuttaa tekstin pienaakkosiksi
void changetoLowerCase(char* string){
    int i = 0;
    int size;

    size = strlen(string);

    while (i < size){
        string[i] = (tolower(string[i]));
        i++;
    }
}



/* Poistaa sy�tteest� muut merkit kuin pienaakkoset a-z tai heittomerkin (')
 * Jos sy�tteess� on muita kuin sallittuja sy�tteit�, palauttaa funktio
 * merkin j�lkeisen sy�tteen osan.
 *
 */
char* checkWord (char* word, char* subWord){
   int i, j;

   subWord = NULL;

   for(i = 0; word[i] != '\0'; i++){
      if (!((word[i] >= 'a' && word[i] <= 'z') || word[i] == '\'')){
         j = i;
         subWord = substring(word, j+2, strlen(word));
         word[j] = '\0';
         break;
      }
   }
   return subWord;
}



// Ottaa osamerkkijonon sy�tteest� annetulta v�lilt� (j - length) ja palauttaa sen.
char* substring(char* word, int j, int length){
   char* subWord;
   int i;

   subWord = malloc(length+1);

   if (subWord == NULL){
      printf("Muistinvaraus ei onnistunut\n");
      exit(1);
   }
   for (i = 0 ; i < length ; i++){
      *(subWord+i) = *(word+j-1);
      word++;
   }

   *(subWord+i) = '\0';

   return subWord;
}



// Binaarinen hakupuu:

// Minimum value of the tree
pbstnode bst_min(pbstnode rt){
	pbstnode x = rt;

	if(x == 0)
		return 0;

	while( x->left != 0)
		x = x->left;

	return x;
}

// Maximum value of the tree
pbstnode bst_max(pbstnode rt){
	pbstnode x = rt;

	if(x == 0)
		return 0;

	while( x->right != 0)
		x = x->right;

	return x;
}

/*
	Searches a node according to key
	and returns a pointer to found node

	Muokattu alkuper�ist� funktiota, jotta vertailut toimivat char[] -tyyppisell� sy�tteell�.
*/
pbstnode bst_search(bst bt, data_type key){
	pbstnode pNode = bt.root;

   while(pNode != 0 && (strcmp(pNode->data, key) != 0)){
      if(strcmp(pNode->data, key) < 0){
			pNode = pNode->right;
		}
		else {
			pNode = pNode->left;
		}
	}

	return pNode;
}

// Prints a node
void print_node(pbstnode n){
	if(n != 0)
		printf(" %d ",n->data);
}

void print_inorder(pbstnode pnode){
	if (pnode != 0) {
		print_inorder(pnode->left);
		print_node(pnode);
		print_inorder(pnode->right);
	}
}

// Prints the whole tree inorder
void print_tree_inorder(bst bt){
	print_inorder(bt.root);
}

/*
	Allocates a node with data key
	and inserts it in the tree

	Muokattu alkuper�ist� funktiota, jotta vertailut toimivat char[] -tyyppisell� sy�tteell�.
*/
void bst_insert(bst *bt, data_type key){
	bstnode *n = (bstnode *)malloc(sizeof(bstnode));
	n->data = key;
	n->parent=n->right=n->left=0;
	pbstnode x = bt->root;
	pbstnode y=0;
	while(x!=0){
		y=x;
      if(strcmp(key, x->data) < 0){
			x = x->left;
      }
      else if (strcmp(key, x->data) > 0){
			x = x->right;
      }
		else{
			return;
		}
	}
	n->parent = y;
	if( y == 0){
      bt->root = n;
	}

   else if(strcmp(key, y->data) < 0){
		y->left = n;
   }
	else{
		y->right = n;
	}
}

/*
	Subroutine for removing
*/
void bst_transplant(bst *bt, pbstnode u, pbstnode v){
	if( u->parent == 0)
		bt->root = v;
	else if( u == (u->parent)->left )
		(u->parent)->left = v;
	else
 		(u->parent)->right = v;

 	if( v != 0)
 		v->parent = u->parent;
}

/*
	Searches a node according to key
	and removes it from the tree
*/
int bst_remove(bst *bt,data_type key) {
	pbstnode x = bst_search(*bt,key);

	if(x==0)
		return 0;

	if(x->left == 0) {
		bst_transplant(bt, x, x->right);
	}
	else if( x->right == 0){
		bst_transplant(bt, x, x->left);
	}
	else {
		pbstnode y = bst_min(x->right);

		if( y->parent != x){
			bst_transplant(bt,y,y->right);
			y->right = x->right;
			(y->right)->parent = y;
		}

		bst_transplant(bt,x,y);
		y->left = x->left;
		(y->left)->parent = y;
	}

	free(x);

	return 1;
}

// Delete the whole tree
void bst_delete(pbstnode node){
	if(node != 0) {
		bst_delete(node->left);
		bst_delete(node->right);
		free(node);
	}
}
